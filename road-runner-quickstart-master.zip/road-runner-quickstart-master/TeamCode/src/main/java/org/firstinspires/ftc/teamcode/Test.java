package org.firstinspires.ftc.teamcode;

import org.firstinspires.ftc.teamcode.AttemptAuto.City;
import org.firstinspires.ftc.teamcode.AttemptAuto.Neighbor;
import org.firstinspires.ftc.teamcode.AttemptAuto.Path;
import org.firstinspires.ftc.teamcode.AttemptAuto.GraphReader;
import org.firstinspires.ftc.teamcode.AttemptAuto.Directions;
import java.util.LinkedList;
import java.util.Queue;
import java.util.ArrayList;
import java.util.List;

// **IMPORTANT** Units on map are 4 "units" = 1 inch **IMPORTANT** //
// **IMPORTANT** Units on map are 4 "units" = 1 inch **IMPORTANT** //
// **IMPORTANT** Units on map are 4 "units" = 1 inch **IMPORTANT** //
// **IMPORTANT** Units on map are 4 "units" = 1 inch **IMPORTANT** //

public class Test {
    public static void main(String[] args) {
        GraphReader reader = new GraphReader();

        reader.readFile("feildTest.txt");
        reader.createCityList();
        reader.addNeighbors();

        List<City> cities = reader.getCities();
        List<City> visitedCities = new ArrayList<>();

        doStuffandDontDisplay("FiveFour", "TwoTwo", reader);
    }

    //idk what the move commands are rn
    //this will work once I figure it out unless it tries to call multiple at once
    //then I will need to make a wait method to wait until the command is done being
    //completed and then have it find the next step although eventally I will need
    //a more efficent version this works for now to see if this actually works.
    public static void testDrive(Directions directions) {
        for (String str: directions.getDirectionList())
        {
            double len = Double.parseDouble(str.substring(str.lastIndexOf(" "), str.length()));
            if (str.toLowerCase().contains("forward"))
            {
                //robot.move(len);
            }
            else if (str.toLowerCase().contains("Turn Left"))
            {
                //robot.turnLeft(len);
            }
            else if (str.toLowerCase().contains("Turn Right"))
            {
                //robot.turnRight(len);
            }
        }
    }

    public static void doStuffandDontDisplay(String name1, String name2, GraphReader reader)
    {
        City startCity = reader.getCityFromName(name1);
        City endCity = reader.getCityFromName(name2);
        Path output = bfsTraversal(startCity, endCity, reader);
        System.out.println(output);

        Directions directions = new Directions(output, reader);
        System.out.println("");
        directions.printDirections();
    }

    public static Path bfsTraversal(City startCity, City endCity, GraphReader map) {
        Path path = new Path();
        path.addCity(startCity);
        if (startCity.equals(endCity)) {
            return path;
        }

        ArrayList<Path> frontier = new ArrayList<Path>();
        frontier.add(path);
        ArrayList<City> explored = new ArrayList<City>();
        explored.add(startCity);

        while (!frontier.isEmpty()) {
            Path currentPath = frontier.remove(0);
            City lastCity = currentPath.getLastCity();
            //System.out.println(lastCity);
            explored.add(lastCity);
            ArrayList<City> neighbors = lastCity.getNeighbor();
            for (City neighbor : neighbors) {
                //System.out.println(neighbor);
                if (!explored.contains(neighbor) && !Path.frontierContainsCity(frontier, neighbor)) {
                    Path newPath = currentPath.getCopy();
                    newPath.addCity(neighbor);

                    if (neighbor.equals(endCity)) {
                        return newPath;
                    }

                    frontier.add(newPath);
                }
            }
        }

        return new Path();
    }
}
